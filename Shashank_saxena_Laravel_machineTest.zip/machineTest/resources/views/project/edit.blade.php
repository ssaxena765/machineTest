<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edt| {{ $project->name }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-RvU0h9K2FhYgH4C3gH0H3N+P6W8+M9pY/0nL8kU0O4+5tMEu4cD8tV8y4nD1Qx5y8u5B9Zl1n1C8t1D4g9fM4w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <h1></h1>
    <section>
        <h2>Edt| {{ $project->name }} <a href="{{ url('projects') }}" class="btn btn-primary" style="float:right">View All
                Project</a></h2>
        <hr>
        <div class="responsive" style="margin-top: 20px;padding:50px">
            <div class="row">
                <div class="col-sm-6">
                    <form id="project-update-form" method="POST">
                        @csrf
                        
                        <div class="form-group">
                            <label for="name">Project Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="{{ $project->name }}" required>
                            
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" id="description" name="description" required>{{ $project->description }}</textarea>
                            
                        </div>
                        
                        <button type="submit" class="btn btn-primary addBtn">Update Project</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <script>
        function isObject(value) {
            return value !== null && typeof value === 'object';
        }
        $("#project-update-form").on("submit", function(event) {
            event.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            $.ajax({
                url: "{{ url('projects/' . $project->id) }}",
                type: "POST",
                data: new FormData(this),
                dataType: 'json',
                contentType: false,
                processData: false,
                cache: false,
                beforeSend: function() {
                    $('.addBtn').prepend('<i class="fa fa-spinner fa-spin"></i>');

                    $('.addBtn').attr("disabled", 'disabled');
                },
                success: function(data) {
                    if (data.success) {
                        // $("#project-update-form")[0].reset();
                        alert('Success: Data Updated Successfully');

                        $('.addBtn').find(".fa-spinner").remove();

                        $('.addBtn').removeAttr("disabled");

                    } else {

                        if (isObject(data.error)) {
                            $.each(data.error, function(key, value) {
                                alert('Error: '+value[0]);
                            });
                        } else {
                            alert('Error: '+data.error);
                        }
                        $('.addBtn').find(".fa-spinner").remove();

                        $('.addBtn').removeAttr("disabled");
                    }
                },
                error: function(xhr) {
                    $.each(xhr.responseJSON.errors, function(key, value) {
                        alert('Error: '+ value);
                    });
                    $('.addBtn').find(".fa-spinner").remove();

                    $('.addBtn').removeAttr("disabled");
                },
            });
        });
    </script>
</body>

</html>
