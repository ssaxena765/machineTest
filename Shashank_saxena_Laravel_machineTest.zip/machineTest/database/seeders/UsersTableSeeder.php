<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

//

use App\Models\Project;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */


     //Custom seeder function to insert 10 users
    // public function run()
    // {
    //     $faker = Faker::create();

    //     for ($i = 0; $i < 10; $i++) {
    //         $users[] = [
    //             'name' => $faker->name,
    //             'email' => $faker->unique()->safeEmail,
    //             'created_at' => now(),
    //             'updated_at' => now(),
    //         ];
    //     }
    //     User::insert($users);
    // }

    public function run()
    {
        // Fetch user IDs from the users table
        $userIds = User::pluck('id')->toArray();

        // Check if there are users available
        if (empty($userIds)) {
            $this->command->info('No users found. Please add some users before running the ProjectSeeder.');
            return;
        }

        $projects = [];

        foreach (range(1, 20) as $index) {
            $projects[] = [
                'name' => 'Project ' . chr(64 + $index), // Generates Project A, Project B, etc.
                'description' => 'Description for Project ' . chr(64 + $index),
                'user_id' => $userIds[array_rand($userIds)], // Randomly assign a user_id from the array
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }

        Project::insert($projects); // Insert all projects in one go
    }

}
