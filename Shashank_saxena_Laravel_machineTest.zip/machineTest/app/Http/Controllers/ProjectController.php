<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Project;
use App\Models\User;
use PhpParser\Node\Stmt\TryCatch;
use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Validator;

class ProjectController extends Controller
{
    //


    //method to show all projects
    public function index()
    {
        try {
            //list all projects
            $projects = Project::with('user')->get();
            // dd($projects);

            // foreach ($projects as $project) {
            //     echo "Project Name: " . $project->name . "<br>";
            //     echo "Description: " . $project->description . "<br>";
            //     echo "User  Name: " . ($project->user ? $project->user->name : 'No User') . "<br>"; 
            //     echo "-----------------------------<br>";
            // }

            $data['projects'] = Project::with('user')->get();
            $data['title'] = 'All Projects';
            return view('project.index', $data);
        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }

    //method for datatable server side for large data handling
    public function getProjects(Request $request)
    {
        try {
            if ($request->ajax()) {
                $data = Project::with('user')->select('projects.*'); // Fetch projects with user relation
                return DataTables::of($data)
                    ->addIndexColumn()
                    ->addColumn('user_name', function ($row) {
                        return $row->user ? $row->user->name : 'No User';
                    })
                    ->addColumn('action', function ($row) {
                        $editButton = '<a href="' . url('projects/' . $row->id . '/edit') . '" class="btn btn-primary btn-sm">Edit</a>';
                        $deleteButton = '<button type="button" class="btn btn-danger btn-sm delete" data-id="' . $row->id . '">Delete</button>';
                        return $editButton . ' ' . $deleteButton;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
            }
            return abort(404);
        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }

    //method to oen form of addingnew project
    public function create()
    {
        try {
            $data['users'] = User::all();
            $data['title'] = 'Create Projects';
            return view('project.create', $data);
        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }


    //saving new entry
    public function store(Request $request)
    {
        try {

            $rules = array(
                'name' => 'required|string|unique:projects,name',
                'user_id' => 'required|exists:users,id',
                'description' => 'required|string|min:50',
            );

            $validate = Validator::make($request->all(), $rules);
            if ($validate->fails()) {
                return response()->json([
                    'error' => $validate->errors()
                ]);
            }


            $project = new Project();
            $project->name = trim($request->name);
            $project->user_id = trim($request->user_id);
            $project->description = trim($request->description);
            $project->save();
            return response()->json(['success' => 'Form submitted successfully.']);



        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }

    //open project edit page
    public function edit($id)
    {
        try {
            $data['title'] = 'Edit Project';
            $project = Project::findOrFail($id); // Fetch the project by ID
            return view('project.edit', compact('project'));
        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }

    //update the project
    public function update(Request $request, $id)
    {
        try {
            // dd($request->all());
            $request->validate([
                'name' => 'required|string',
                'description' => 'required|string|min:50',
            ]);

            $project = Project::findOrFail($id);
            $project->update($request->all());

            return response()->json(['success' => 'Form updated successfully.']);
        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }





    //delete the project
    public function destroy($id)
    {
        // dd($id);
        try {
            $record = Project::find($id);
            if ($record) {
                $record->delete();
                return response()->json(['success' => 'Record deleted successfully.']);
            }

            return response()->json(['error' => 'Record not found.'], 404);

        } catch (Exception $th) {
            return response()->json([
                'error' => $th->getMessage()
            ]);
        }
    }
}
