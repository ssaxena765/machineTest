<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProjectController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return 'Goto URL : <a href="/projects">/projects</a>';
});

Route::get('/projects',[ProjectController::class, 'index']);
Route::get('/projects/data', [ProjectController::class, 'getProjects'])->name('projects.data');
Route::get('/projects/create',[ProjectController::class, 'create']);
Route::post('/projects',[ProjectController::class, 'store']);
Route::get('/projects/{id}/edit', [ProjectController::class, 'edit']);
// Route::put('/projects/{id}', [ProjectController::class, 'update']);   {This PUT method is not working in my apache, So due to time constraint i am using post method instead}
Route::post('/projects/{id}', [ProjectController::class, 'update']);
Route::delete('/projects/{id}', [ProjectController::class, 'destroy']);
